const fs = require('node:fs');
const assert = require('node:assert/strict');
const {launch, Key} = require('/workspace/autocompletele/chrome-extension/e2e-firefox/helper');
const out = '/workspace/.onboarding/autocompletele/aesthetic-popup';
const shots=[];
(async()=>{
 const app=await launch();
 const d=app.driver;
 try {
  await d.manage().window().setRect({width:760,height:800});
  await app.openOptions();
  await d.executeScript(list=>self.ShorthandStorage.replaceAll(list),[
   {trigger:'hello/',expansion:'Hi there! Thanks for getting in touch.'},
   {trigger:'meet/',expansion:'Would tomorrow afternoon work for a quick call?'},
   {trigger:'long-trigger-'.repeat(12)+'/',expansion:'A long expansion '.repeat(30)},
   {trigger:'thanks/',expansion:'Thank you for your help — I really appreciate it.'}
  ]);
  await d.switchTo().newWindow('tab');
  const popupHandle=await d.getWindowHandle();
  for(const theme of ['light','dark']) {
   await d.setContext('chrome');
   await d.executeScript('Services.prefs.setIntPref("layout.css.prefers-color-scheme.content-override",arguments[0])',theme==='dark'?0:1);
   await d.setContext('content');
   await d.switchTo().window(popupHandle);
   await d.get(`${app.extensionURL}/src/popup.html`);
   await d.wait(async()=>await d.executeScript('return document.querySelectorAll(".result").length')===4,5000);
   assert.equal(await d.executeScript('return matchMedia("(prefers-color-scheme: dark)").matches'),theme==='dark');
   assert.equal(await d.executeScript('return document.getElementById("search").labels[0].textContent'),'Search shorthands');
   assert(await d.executeScript('const r=document.querySelector("#results");return r.scrollWidth<=r.clientWidth'));
   const shot=async(name,selector='body')=>{
    const path=`${out}/firefox-${name}.png`;
    fs.writeFileSync(path,await (await app.element(selector)).takeScreenshot(), 'base64');
    shots.push(path);
   };
   await (await app.element('#search')).sendKeys(Key.TAB,Key.SHIFT,Key.TAB,Key.NULL);
   await (await app.element('#search')).click();
   await shot(`popup-${theme}-focus`);
   await (await app.element('#search')).sendKeys(Key.ARROW_DOWN);
   assert(await d.executeScript('return document.activeElement.classList.contains("result")'));
   await shot(`popup-${theme}-selected`);
   const target=await app.element('.result:nth-child(2)');
   await d.actions({async:true}).move({origin:target}).press().perform();
   await shot(`popup-${theme}-pressed`);
   await d.actions({async:true}).release().perform();
   await app.fill('#search','no-match-at-all');
   await (await app.element('#enabled')).click();
   await d.wait(async()=>await (await app.element('#status')).getAttribute('data-state')==='paused',5000);
   await shot(`popup-${theme}-empty-paused`);
   await (await app.element('#enabled')).click();
   await app.openFixture();
   await (await app.element('#inp')).sendKeys(';;');
   await d.wait(async()=>await d.executeScript('return !!document.getElementById("shorthand-picker-host")'),5000);
   assert.equal(await d.executeScript('return matchMedia("(prefers-color-scheme: dark)").matches'),theme==='dark');
   await shot(`picker-${theme}-selected`,'#shorthand-picker-host');
   await (await app.element('#inp')).sendKeys(Key.ARROW_DOWN);
   await shot(`picker-${theme}-selected-next`,'#shorthand-picker-host');
   await (await app.element('#inp')).sendKeys('zzzzzzzzzz');
   await shot(`picker-${theme}-empty`,'#shorthand-picker-host');
   await (await app.element('#inp')).sendKeys(Key.ESCAPE);
  }
  console.log(`Firefox real-theme and popup label/overflow/state assertions passed; ${shots.length} screenshots.`);
 } finally {await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
