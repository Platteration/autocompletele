const fs = require('node:fs');
const assert = require('node:assert/strict');
const { launch } = require('/workspace/autocompletele/chrome-extension/e2e/helper');
const out = '/workspace/.onboarding/autocompletele/aesthetic-popup';
(async () => {
 const app = await launch({shorthands:[
  {trigger:'hello/',expansion:'Hi there! Thanks for getting in touch.'},
  {trigger:'meet/',expansion:'Would tomorrow afternoon work for a quick call?'},
  {trigger:'long-trigger-'.repeat(12)+'/',expansion:'A long expansion '.repeat(30)},
  {trigger:'thanks/',expansion:'Thank you for your help — I really appreciate it.'}
 ]});
 try {
  const popup = await app.context.newPage();
  await popup.setViewportSize({width:360,height:600});
  for (const theme of ['light','dark']) {
   await popup.emulateMedia({colorScheme:theme});
   await popup.goto(`chrome-extension://${app.extensionId}/src/popup.html`);
   await popup.waitForSelector('.result');
   assert.equal(await popup.getByRole('searchbox',{name:'Search shorthands'}).count(),1);
   assert.equal(await popup.evaluate(()=>document.documentElement.scrollWidth),360);
   assert(await popup.locator('.trigger').nth(2).evaluate(el=>el.scrollWidth>el.clientWidth));
   await popup.locator('#search').focus();
   await popup.locator('body').screenshot({path:`${out}/chrome-popup-${theme}-focus.png`});
   await popup.keyboard.press('ArrowDown');
   await popup.locator('body').screenshot({path:`${out}/chrome-popup-${theme}-selected.png`});
   await popup.locator('.result').nth(1).hover();
   await popup.mouse.down();
   await popup.locator('body').screenshot({path:`${out}/chrome-popup-${theme}-pressed.png`});
   await popup.mouse.up();
   await popup.fill('#search','no-match-at-all');
   await popup.locator('#enabled').uncheck();
   await popup.waitForFunction(()=>document.getElementById('status').dataset.state==='paused');
   await popup.locator('body').screenshot({path:`${out}/chrome-popup-${theme}-empty-paused.png`});
   await popup.locator('#enabled').check();
   await app.page.emulateMedia({colorScheme:theme});
   await app.page.bringToFront();
   await app.page.fill('#inp','');
   await app.page.keyboard.type(';;');
   await app.page.waitForSelector('#shorthand-picker-host');
   await app.page.locator('#shorthand-picker-host').screenshot({path:`${out}/chrome-picker-${theme}-selected.png`});
   await app.page.keyboard.press('ArrowDown');
   await app.page.locator('#shorthand-picker-host').screenshot({path:`${out}/chrome-picker-${theme}-selected-next.png`});
   await app.page.keyboard.type('zzzzzzzzzz');
   await app.page.locator('#shorthand-picker-host').screenshot({path:`${out}/chrome-picker-${theme}-empty.png`});
   await app.page.keyboard.press('Escape');
  }
  assert.deepEqual(app.errors,[]);
  console.log('Chrome screenshots and popup search/overflow/paused-state assertions passed.');
 } finally {await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
