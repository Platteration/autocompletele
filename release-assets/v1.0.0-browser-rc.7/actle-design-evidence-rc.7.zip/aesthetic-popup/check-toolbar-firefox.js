const {launch,By}=require('/workspace/autocompletele/chrome-extension/e2e-firefox/helper');
const fs=require('node:fs');
(async()=>{
 const app=await launch();
 try {
  const d=app.driver;
  await d.manage().window().setRect({width:1000,height:900});
  await d.setContext('chrome');
  console.log('buttons',await d.executeScript('return Array.from(document.querySelectorAll("toolbarbutton")).filter(x=>/extension|shorthand/i.test(x.id+" "+x.getAttribute("label"))).map(x=>({id:x.id,label:x.getAttribute("label"),hidden:x.hidden}))'));
  await d.findElement(By.id('unified-extensions-button')).click();
  console.log('menu',await d.executeScript('return Array.from(document.querySelectorAll(".unified-extensions-item")).map(x=>({text:x.textContent.trim(),html:x.outerHTML.slice(0,2500)}))'));
  await d.findElement(By.css('.unified-extensions-item-action-button')).click();
  await new Promise(resolve=>setTimeout(resolve,1200));
  console.log('popup browsers',await d.executeScript('return Array.from(document.querySelectorAll("browser")).map(x=>({id:x.id,src:x.getAttribute("src"),remote:x.getAttribute("remote"),doc:!!x.contentDocument,rect:JSON.stringify(x.getBoundingClientRect())}))'));
  const frame=await d.findElement(By.css('browser[remote="true"]'));
  console.log('frame class',await frame.getAttribute('class'));
  await d.switchTo().frame(frame);
  console.log('inner',await d.executeScript('return {url:location.href,host:document.getElementById("host")?.textContent,siteDisabled:document.getElementById("site")?.disabled,width:innerWidth,height:innerHeight}'));
  fs.writeFileSync('/workspace/.onboarding/autocompletele/aesthetic-popup/firefox-toolbar-native.png',await d.takeScreenshot(),'base64');
 }finally{await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
