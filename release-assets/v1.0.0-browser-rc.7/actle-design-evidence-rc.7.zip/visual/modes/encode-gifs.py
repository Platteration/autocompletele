from pathlib import Path
from PIL import Image
import json
p=Path(__file__).parent
metadata=[]
for folder in sorted(p.glob('*-frames')):
 if not (folder/'times.json').exists():continue
 records=json.loads((folder/'times.json').read_text())
 frames=[Image.open(folder/r['file']).convert('RGB') for r in records]
 count=min(16,len(frames));strip=Image.new('RGB',(frames[0].width,frames[0].height*count))
 for i in range(count):strip.paste(frames[round(i*(len(frames)-1)/max(1,count-1))],(0,i*frames[0].height))
 palette=strip.quantize(colors=256)
 frames=[f.quantize(palette=palette,dither=Image.Dither.NONE) for f in frames]
 ticks=[round(r['seconds']*100)*10 for r in records]
 # Keep real timing with cumulative GIF ticks; merge sub-10ms captures rather than lengthening them.
 kept=[];durations=[]
 for i,frame in enumerate(frames):
  end=ticks[i+1] if i+1<len(ticks) else ticks[i]+900
  span=end-ticks[i]
  if span<=0:continue
  kept.append(frame);durations.append(span)
 dest=p/(folder.name.removesuffix('-frames')+'.gif')
 kept[0].save(dest,save_all=True,append_images=kept[1:],duration=durations,loop=0,optimize=False,disposal=1)
 check=Image.open(dest)
 metadata.append({'file':dest.name,'capturedFrames':len(frames),'encodedFrames':check.n_frames,'durationMs':sum(durations),'bytes':dest.stat().st_size,'dimensions':check.size})
(p/'encoded-gifs.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata,indent=2))
