// Read real closed-shadow content through browser automation; no rendering hooks.
function inspect(element) {
 const canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
 const rgba=value=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=value;ctx.fillRect(0,0,1,1);const c=[...ctx.getImageData(0,0,1,1).data];return[...c.slice(0,3),c[3]/255];};
 const over=(a,b)=>a.slice(0,3).map((v,i)=>v*a[3]+b[i]*(1-a[3]));
 const background=e=>{const nodes=[];for(;e;e=e.parentElement||e.getRootNode().host)nodes.unshift(e);return nodes.reduce((color,node)=>over(rgba(getComputedStyle(node).backgroundColor),color),[255,255,255]);};
 const lum=color=>color.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0);
 const ratio=(a,b)=>{const[x,y]=[lum(a),lum(b)];return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
 const rect=r=>({x:r.x,y:r.y,width:r.width,height:r.height});
 const describe=e=>{const s=getComputedStyle(e);return{tag:e.tagName,class:e.className,text:e.textContent,rect:rect(e.getBoundingClientRect()),color:s.color,background:s.backgroundColor,resolvedBackground:background(e),contrast:ratio(over(rgba(s.color),background(e)),background(e)),opacity:s.opacity,font:s.font,lineHeight:s.lineHeight,letterSpacing:s.letterSpacing,whiteSpace:s.whiteSpace,visibility:s.visibility};};
 return{now:performance.now(),glyphs:describe(element),parent:describe(element.parentElement),children:[...element.children].map(describe),field:describe(document.getElementById('message'))};
}
module.exports = async function readOverlay(app,session,By) {
 try {
  if(session){
   const {root}=await session.send('DOM.getDocument',{depth:-1,pierce:true});
   let found;
   function walk(node){if(found)return;const a=node.attributes||[];const i=a.indexOf('class');if(i>=0&&a[i+1].split(/\s+/).includes('glyphs'))found=node;for(const child of [...node.children||[],...node.shadowRoots||[]])walk(child);}
   walk(root);if(!found)return null;
   const {object}=await session.send('DOM.resolveNode',{backendNodeId:found.backendNodeId});
   const {result,exceptionDetails}=await session.send('Runtime.callFunctionOn',{objectId:object.objectId,functionDeclaration:'function(){return ('+inspect.toString()+')(this);}',returnByValue:true});
   await session.send('Runtime.releaseObject',{objectId:object.objectId});
   if(exceptionDetails)return{inspectionError:exceptionDetails.text};
   return result.value;
  }
  const host=await app.element('#actle-expansion-feedback'),shadow=await host.getShadowRoot(),glyphs=await shadow.findElement(By.css('.glyphs'));
  return await app.driver.executeScript(inspect,glyphs);
 }catch(error){return{inspectionError:String(error.message||error)};}
};
