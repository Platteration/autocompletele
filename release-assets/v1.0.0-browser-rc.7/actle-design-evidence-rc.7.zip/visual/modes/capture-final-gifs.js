const assert=require('node:assert/strict'),fs=require('node:fs'),http=require('node:http');
const {demo}=require('./demo.js');const root='/workspace/autocompletele/chrome-extension',out=__dirname+'/final-gifs';fs.mkdirSync(out,{recursive:true});
const server=http.createServer((req,res)=>{const q=new URL(req.url,'http://local').searchParams;res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(demo('textarea',q.get('mode')||'Expand',true));});
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const metadata=[];
async function run(browser){
 const app=await require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')).launch({shorthands:[{trigger:'yg',expansion:'you got it'}]});const page=app.page,driver=app.driver;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 try{
  if(!page){await app.openOptions();await driver.executeScript(()=>self.ShorthandStorage.replaceAll([{trigger:'yg',expansion:'you got it'}]));}
  for(const theme of ['light'])for(const mode of ['expand','casino']){
   if(page){await app.worker.evaluate(mode=>self.ShorthandStorage.saveSettings({animationMode:mode}),mode);await page.setViewportSize({width:760,height:560});await page.emulateMedia({colorScheme:theme,reducedMotion:'no-preference'});}
   else{await driver.switchTo().window(app.optionsHandle);await driver.executeScript(mode=>self.ShorthandStorage.saveSettings({animationMode:mode}),mode);await driver.switchTo().window(app.fixtureHandle);await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);Services.prefs.setIntPref("ui.prefersReducedMotion",0);',theme==='dark'?1:0);await driver.setContext('content');await driver.manage().window().setRect({width:760,height:560});const extra=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:760+extra.w,height:560+extra.h});}
   const url=`http://127.0.0.1:${server.address().port}/?mode=${mode}`;
   if(page)await page.goto(url);else await driver.get(url);
   const field=page?page.locator('#message'):await app.element('#message');if(page)await field.focus();else await field.click();
   const frames=[],dir=`${out}/${browser}-${theme}-${mode}-frames`;fs.mkdirSync(dir,{recursive:true});
   let session,stop=false,capturePromise;
   if(page){session=await app.context.newCDPSession(page);session.on('Page.screencastFrame',event=>{frames.push({data:event.data,time:event.metadata.timestamp});void session.send('Page.screencastFrameAck',{sessionId:event.sessionId});});await session.send('Page.startScreencast',{format:'png',everyNthFrame:1,maxWidth:760,maxHeight:560});}
   else{capturePromise=(async()=>{while(!stop){const before=Date.now(),data=await driver.takeScreenshot(),after=Date.now();frames.push({data,time:(before+after)/2000});}})();}
   await delay(450);if(page)await field.pressSequentially('y');else await field.sendKeys('y');
   await delay(350);if(page)await field.pressSequentially('g');else await field.sendKeys('g');
   const state=await evaluate(()=>{const e=document.getElementById('message');return{value:e.value,active:document.activeElement===e,overlay:!!document.getElementById('actle-expansion-feedback')};});
   assert.equal(state.value,'you got it');assert.ok(state.active);assert.equal(state.overlay,mode!=='off');
   await delay(1700);
   assert.equal(await evaluate(()=>document.getElementById('message').value),'you got it');
   assert.equal(await evaluate(()=>!!document.getElementById('actle-expansion-feedback')),false);
   await delay(500);
   if(session){await session.send('Page.stopScreencast');await session.detach();}else{stop=true;await capturePromise;}
   const times=frames.map((f,i)=>{const file=`frame-${String(i).padStart(3,'0')}.png`;fs.writeFileSync(dir+'/'+file,Buffer.from(f.data,'base64'));return{file,seconds:f.time-frames[0].time};});fs.writeFileSync(dir+'/times.json',JSON.stringify(times,null,2));
   metadata.push({browser,theme,mode,frames:frames.length,seconds:times.at(-1).seconds,viewport:[760,560],state,actualBrowserCapture:true});fs.writeFileSync(out+'/gif-metadata.json',JSON.stringify(metadata,null,2));console.log(browser,theme,mode,frames.length,'frames');
  }
 }finally{await app.close();}
}
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));try{for(const b of ['chrome'])await run(b);}finally{await new Promise(r=>server.close(r));}})().catch(e=>{console.error(e);process.exitCode=1;});
