from pathlib import Path
from PIL import Image,ImageDraw
import json
p=Path(__file__).parent
rows=json.loads((p/'measurements.json').read_text())
for browser in ['chrome','firefox']:
 for theme in ['light','dark']:
  for mode in ['expand','casino','off']:
   selected=[r for r in rows if r['browser']==browser and r['theme']==theme and r['mode']==mode]
   columns=4 if mode!='off' else 2
   cellw=330 if browser=='chrome' else 510
   cellh=280
   total=len(selected)*(4 if mode!='off' else 1)
   sheet=Image.new('RGB',(cellw*columns,cellh*((total+columns-1)//columns)),'#d9e2ee');draw=ImageDraw.Draw(sheet)
   n=0
   for r in selected:
    for s in r['snapshots']:
     state=s['state'];im=Image.open(p/f'{browser}-{theme}-{mode}-{r["scenario"]["id"]}-{state}.png')
     box=s['fieldRect'];left=max(0,int(box['x'])-8);top=max(0,int(box['y'])-35);right=min(im.width,int(box['x']+box['width'])+8);bottom=min(im.height,int(box['y']+box['height'])+30)
     crop=im.crop((left,top,right,bottom));x=n%columns*cellw;y=n//columns*cellh
     sheet.paste(crop,(x+8,y+26));draw.text((x+8,y+8),f'{r["scenario"]["id"]} · {mode} · {state}',fill='#172033');n+=1
   sheet.save(p/f'{browser}-{theme}-{mode}-sheet.png')
if (p/'settings-metrics.json').exists():
 settings=json.loads((p/'settings-metrics.json').read_text())
 for browser in ['chrome','firefox']:
  for theme in ['light','dark']:
   selected=[r for r in settings if r['browser']==browser and r['theme']==theme]
   ims=[Image.open(p/r['file']) for r in selected];w=max(im.width for im in ims)+20;h=max(im.height for im in ims)+40
   sheet=Image.new('RGB',(w*2,h*3),'#d9e2ee');draw=ImageDraw.Draw(sheet)
   for i,(r,im)in enumerate(zip(selected,ims)):
    x=i%2*w;y=i//2*h;sheet.paste(im,(x+10,y+28));draw.text((x+10,y+8),r['state'],fill='#172033')
   sheet.save(p/f'{browser}-{theme}-settings-sheet.png')
