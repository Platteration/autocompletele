const assert=require('node:assert/strict'),fs=require('node:fs');
const root='/workspace/autocompletele/chrome-extension',out=__dirname,records=[];
async function run(browser){
 const helper=require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')),app=await helper.launch();
 const page=app.page,driver=app.driver;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const wait=fn=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 const choose=async mode=>{if(page)await page.locator('#animationMode').selectOption(mode);else await(await app.element(`#animationMode option[value="${mode}"]`)).click();};
 const shot=async(theme,state)=>{
  const file=`${browser}-${theme}-settings-${state}.png`;
  if(page)await page.locator('#animationMode').locator('..').screenshot({path:out+'/'+file});
  else fs.writeFileSync(out+'/'+file,Buffer.from(await(await app.element('#animationMode')).findElement(helper.By.xpath('..')).takeScreenshot(),'base64'));
  const data=await evaluate(()=>{
   const select=document.getElementById('animationMode'),row=select.parentElement,box=row.getBoundingClientRect(),style=getComputedStyle(select);
   const color=v=>{const c=document.createElement('canvas').getContext('2d');c.fillStyle=v;c.fillRect(0,0,1,1);const rgba=[...c.getImageData(0,0,1,1).data];return[...rgba.slice(0,3),rgba[3]/255];};
   const blend=(f,b)=>f.slice(0,3).map((v,i)=>v*f[3]+b[i]*(1-f[3]));
   const bg=e=>{const ancestors=[];for(;e;e=e.parentElement)ancestors.unshift(e);return ancestors.reduce((v,e)=>blend(color(getComputedStyle(e).backgroundColor),v),[255,255,255]);};
   const lum=v=>v.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4;}).reduce((s,x,i)=>s+x*[.2126,.7152,.0722][i],0);
   const ratio=(a,b)=>{const[x,y]=[lum(a),lum(b)];return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
   const text=[...row.querySelectorAll('strong,select,small,a,span')].filter(e=>e.getClientRects().length&&(e.textContent.trim()||e.tagName==='SELECT')).map(e=>{const background=bg(e),s=getComputedStyle(e);return{id:e.id||e.tagName,color:s.color,background,ratio:ratio(blend(color(s.color),background),background),disabled:e.disabled===true};});
   return{value:select.value,disabled:select.disabled,focused:document.activeElement===select,outline:{style:style.outlineStyle,width:style.outlineWidth,color:style.outlineColor},message:document.getElementById('animationMsg').textContent,borderContrast:ratio(color(style.borderTopColor).slice(0,3),bg(select)),text,box:{left:box.left,right:box.right},viewport:{width:innerWidth,height:innerHeight}};
  });
  assert.ok(data.box.left>=0&&data.box.right<=data.viewport.width);if(state==='focused'){assert.ok(data.focused);assert.ok(parseFloat(data.outline.width)>0);}if(!data.disabled)assert.ok(data.borderContrast>=3);assert.ok(data.text.filter(t=>!t.disabled).every(t=>t.ratio>=4.5),JSON.stringify(data.text));records.push({browser,theme,state,file,...data});
 };
 try{
  for(const theme of ['light','dark']){
   if(page){await page.setViewportSize({width:320,height:900});await page.emulateMedia({colorScheme:theme});await app.worker.evaluate(()=>self.ShorthandStorage.saveSettings({animationMode:'expand'}));await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);await page.waitForSelector('#animationMode');}
   else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);',theme==='dark'?1:0);await driver.setContext('content');await app.openOptions();await evaluate(()=>self.ShorthandStorage.saveSettings({animationMode:'expand'}));await app.openOptions();await driver.manage().window().setRect({width:500,height:900});const extra=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:500+extra.w,height:900+extra.h});}
   await evaluate(()=>document.getElementById('animationMode').scrollIntoView({block:'center'}));await shot(theme,'initial-expand');
   if(page){await page.locator('#animationMode').focus();await page.keyboard.press('Tab');await page.keyboard.press('Shift+Tab');}
   else{await(await app.element('#animationMode')).click();await driver.actions().sendKeys(helper.Key.TAB).keyDown(helper.Key.SHIFT).sendKeys(helper.Key.TAB).keyUp(helper.Key.SHIFT).perform();}
   await shot(theme,'focused');
   await choose('casino');await wait(()=>!document.getElementById('animationMode').disabled&&document.getElementById('animationMsg').textContent.includes('saved: Casino'));await shot(theme,'saved-casino');
   await evaluate(()=>{window.__realModeSave=self.ShorthandStorage.saveSettings;self.ShorthandStorage.saveSettings=()=>new Promise((resolve,reject)=>{window.__visualReject=reject;});});
   await choose('off');await wait(()=>document.getElementById('animationMode').disabled);await shot(theme,'pending-disabled');
   await evaluate(()=>window.__visualReject(new Error('Connection interrupted')));await wait(()=>!document.getElementById('animationMode').disabled&&document.getElementById('animationMsg').classList.contains('error'));await shot(theme,'save-error');
   assert.equal(await evaluate(()=>document.getElementById('animationMode').value),'casino');
   await evaluate(()=>self.ShorthandStorage.saveSettings=window.__realModeSave);
   await choose('off');await wait(()=>!document.getElementById('animationMode').disabled&&document.getElementById('animationMsg').textContent.includes('saved: Off'));await shot(theme,'saved-off');
   assert.equal(await evaluate(()=>self.ShorthandStorage.getAll().then(d=>d.settings.animationMode)),'off');
  }
 }finally{await app.close();}
}
(async()=>{try{for(const b of ['chrome','firefox'])await run(b);}finally{fs.writeFileSync(out+'/settings-metrics.json',JSON.stringify(records,null,2));}console.log(JSON.stringify({captures:records.length,minText:Math.min(...records.flatMap(r=>r.text.filter(t=>!t.disabled).map(t=>t.ratio)))}));})().catch(e=>{console.error(e);process.exitCode=1;});
