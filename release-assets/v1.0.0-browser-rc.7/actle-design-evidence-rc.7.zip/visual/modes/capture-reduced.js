const assert=require('node:assert/strict'),fs=require('node:fs'),http=require('node:http');
const root='/workspace/autocompletele/chrome-extension',out=__dirname+'/reduced';fs.mkdirSync(out,{recursive:true});
const {demo,scenarios}=require('./demo.js');
const readOverlay=require('./read-overlay.js');
const records=[];
const server=http.createServer((req,res)=>{const q=new URL(req.url,'http://local').searchParams;res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(demo(q.get('type')||'textarea',q.get('mode')||'Expand'));});
const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function run(browser){
 const helper=require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js'));
 const app=await helper.launch({shorthands:[{trigger:'yg',expansion:'you got it'}]});
 const page=app.page,driver=app.driver;
 let options;const session=page?await app.context.newCDPSession(page):null;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const wait=fn=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 const shot=async file=>{if(page)await page.screenshot({path:out+'/'+file});else fs.writeFileSync(out+'/'+file,Buffer.from(await driver.takeScreenshot(),'base64'));};
 const size=async(width,height)=>{if(page)await page.setViewportSize({width,height});else{await driver.manage().window().setRect({width,height});const extra=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:width+extra.w,height:height+extra.h});}};
 const get=()=>evaluate(()=>{const e=document.getElementById('message'),host=document.getElementById('actle-expansion-feedback'),r=e.getBoundingClientRect(),s=getComputedStyle(e);return{now:performance.now(),value:e.isContentEditable?e.textContent:e.value,focused:document.activeElement===e,selection:e.isContentEditable?getSelection().anchorOffset:e.selectionStart,host:!!host,hostPointerEvents:host?getComputedStyle(host).pointerEvents:null,hostAriaHidden:host?.getAttribute('aria-hidden'),fieldRect:{x:r.x,y:r.y,width:r.width,height:r.height},style:{font:s.font,lineHeight:s.lineHeight,color:s.color,background:s.backgroundColor,padding:s.padding,border:s.borderWidth,letterSpacing:s.letterSpacing},scroll:{left:e.scrollLeft,top:e.scrollTop},viewport:{width:innerWidth,height:innerHeight},overflow:document.documentElement.scrollWidth>innerWidth,events:window.__visualEvents,inputEvents:window.__visualInputs};});
 const selectMode=async mode=>{
  if(page){await options.locator('#animationMode').selectOption(mode);await options.waitForFunction(mode=>self.ShorthandStorage.getAll().then(r=>r.settings.animationMode===mode),mode);}
  else{await driver.switchTo().window(app.optionsHandle);await (await app.element(`#animationMode option[value="${mode}"]`)).click();await driver.wait(()=>driver.executeScript('return self.ShorthandStorage.getAll().then(r=>r.settings.animationMode===arguments[0])',mode),5000);await driver.switchTo().window(app.fixtureHandle);}
 };
 try{
  if(page){options=await app.context.newPage();await options.goto(`chrome-extension://${app.extensionId}/src/options.html`);await options.waitForSelector('#animationMode');}
  else{await app.openOptions();await driver.executeScript(()=>self.ShorthandStorage.replaceAll([{trigger:'yg',expansion:'you got it'}]));await driver.switchTo().window(app.fixtureHandle);}
  for(const theme of ['light','dark']){
   if(page){await page.emulateMedia({colorScheme:theme,reducedMotion:'reduce'});await options.emulateMedia({colorScheme:theme,reducedMotion:'reduce'});}
   else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);Services.prefs.setIntPref("ui.prefersReducedMotion",1);',theme==='dark'?1:0);await driver.setContext('content');}
   await size(browser==='chrome'?320:500,760);
   for(const mode of ['expand','casino']){
    await selectMode(mode);if(page)await page.bringToFront();
    for(const scenario of scenarios.filter(s=>s.id==='input')){
     const url=`http://127.0.0.1:${server.address().port}/?type=${scenario.type}&mode=${mode}`;
     if(page)await page.goto(url);else await driver.get(url);
     await evaluate(s=>{
      const e=document.getElementById('message'),initial=s.prefix+'y'+s.suffix,caret=s.prefix.length+1;
      if(e.isContentEditable){e.textContent=initial;e.focus();const range=document.createRange();range.setStart(e.firstChild,caret);range.collapse(true);getSelection().removeAllRanges();getSelection().addRange(range);}
      else{e.value=initial;e.focus();e.setSelectionRange(caret,caret);}
      if(s.scroll){e.scrollTop=e.scrollHeight;e.scrollLeft=e.scrollWidth;}
      window.__visualEvents=[];window.__visualInputs=[];
      e.addEventListener('input',event=>window.__visualInputs.push({time:performance.now(),value:e.isContentEditable?e.textContent:e.value,inputType:event.inputType,trusted:event.isTrusted}));
      new MutationObserver(ms=>{for(const m of ms)for(const key of ['addedNodes','removedNodes'])for(const n of m[key])if(n.id==='actle-expansion-feedback')window.__visualEvents.push({action:key,time:performance.now()});}).observe(document.documentElement,{childList:true,subtree:true});
     },scenario);
     await evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
     const field=page?page.locator('#message'):await app.element('#message');
     if(page)await field.pressSequentially('g');else await field.sendKeys('g');
     const expected=scenario.prefix+'you got it'+scenario.suffix,immediate=await get(),id=`${browser}-${theme}-${mode}-${scenario.id}`;
     assert.equal(immediate.value,expected,id+' real value');assert.ok(immediate.focused,id+' focus');assert.ok(!immediate.overflow,id+' overflow');
     const snapshots=[];
     if(true){assert.equal(immediate.host,false);await shot(id+'-reduced.png');snapshots.push({state:'reduced',...await get()});}
     else{
      // Record unsupported editors/fallbacks accurately; report rather than silently passing a missing visual effect.
      await shot(id+'-early.png');snapshots.push({state:'early',...await get(),overlay:immediate.host?await readOverlay(app,session,helper.By):null});
      const start=immediate.events.find(e=>e.action==='addedNodes')?.time||immediate.now;
      const now=await evaluate(()=>performance.now());await delay(Math.max(0,350-(now-start)));
      await shot(id+'-middle.png');snapshots.push({state:'middle',...await get(),overlay:await readOverlay(app,session,helper.By)});
      const beforeSettled=await evaluate(()=>performance.now());await delay(Math.max(0,615-(beforeSettled-start)));
      await shot(id+'-settled.png');snapshots.push({state:'settled',...await get(),overlay:await readOverlay(app,session,helper.By)});
      await wait(()=>!document.getElementById('actle-expansion-feedback'));
      await shot(id+'-end.png');snapshots.push({state:'end',...await get()});
     }
     for(const s of snapshots){assert.equal(s.value,expected,id+' stable backing text');assert.ok(s.focused,id+' stable focus');}
     if(page)await field.pressSequentially('!');else await field.sendKeys('!');
     const continued=await get();assert.equal(continued.value,scenario.prefix+'you got it!'+scenario.suffix,id+' continued typing');assert.ok(continued.focused);assert.equal(continued.events.length,0,'Reduced motion never creates an overlay');assert.equal(continued.host,false);
     records.push({browser,theme,mode,scenario,immediate,snapshots,continued});fs.writeFileSync(out+'/measurements.json',JSON.stringify(records,null,2));console.log(id+' '+(mode==='off'?'instant':immediate.host?'animated':'FALLBACK'));
    }
   }
  }
 }finally{await app.close();}
}
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));try{for(const b of ['chrome','firefox'])await run(b);const fallback=records.filter(r=>r.mode!=='off'&&!r.snapshots.some(s=>s.overlay?.glyphs)).map(r=>({browser:r.browser,theme:r.theme,mode:r.mode,scenario:r.scenario.id}));console.log(JSON.stringify({cases:records.length,screenshots:records.reduce((n,r)=>n+r.snapshots.length,0),fallback},null,2));}finally{await new Promise(resolve=>server.close(resolve));}})().catch(e=>{console.error(e);process.exitCode=1;});
