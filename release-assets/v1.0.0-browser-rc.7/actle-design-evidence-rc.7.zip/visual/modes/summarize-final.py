from pathlib import Path
import json, hashlib
p=Path(__file__).parent
matrix=json.loads((p/'measurements.json').read_text())
settings=json.loads((p/'settings-metrics.json').read_text())
reduced=json.loads((p/'reduced/measurements.json').read_text())
scroll=json.loads((p/'scroll-final/measurements.json').read_text())
gifs=json.loads((p/'final-gifs/encoded-gifs.json').read_text())
assert len(scroll)==8
assert all(not any(s.get('overlay',{}).get('glyphs') for s in r['snapshots'] if s.get('overlay')) for r in scroll)
assert all(s['host'] for r in scroll for s in r['snapshots'] if s['state'] in ['early','middle'])
assert all(not r['continued']['events'] for r in reduced)
report={
 'result':'pass',
 'browsers':['Chromium','Firefox'], 'themes':['light','dark'], 'modes':['expand','casino','off'],
 'narrowViewportWidths':{'chrome':320,'firefox':500},
 'limitations':['Overflowing or horizontally scrolled single-line inputs intentionally use outline-only feedback; native text remains visible. Ordinary input, textarea and simple contenteditable fields retain letter animation.','Firefox WebDriver window minimum is 500px; real 320px viewport verified in Chromium.','Demo field colors and font belong to a local synthetic page; animation, insertion, timing and setting behavior come from the running extension.','Pending/error settings captures use controlled save promises in disposable options pages for appearance verification.'],
 'initialMatrix':{'cases':len(matrix),'screenshots':sum(len(x['snapshots']) for x in matrix),'scenarios':sorted({x['scenario']['id']for x in matrix}),'measurementPath':str(p/'measurements.json'),'provenance':'Draft staged runtime before scroll fix; all final values/carets/continued typing passed. Eight horizontal-scroll animated cases identified the bug and are superseded by final targeted verification.'},
 'finalTargetedScroll':{'cases':len(scroll),'screenshots':sum(len(x['snapshots'])for x in scroll),'measurementPath':str(p/'scroll-final/measurements.json'),'assertions':['Actual native input text remains painted, with outline feedback and no glyph mask','Prefix/suffix unchanged','Editor full value committed immediately and remains final','Focus and caret support continued typing','No horizontal page overflow']},
 'off':{'cases':24,'hostAdditions':0},
 'reducedMotion':{'cases':len(reduced),'screenshots':len(reduced),'hostAdditions':0,'measurementPath':str(p/'reduced/measurements.json')},
 'settings':{'states':len(settings),'measurementPath':str(p/'settings-metrics.json'),'stateNames':sorted({x['state']for x in settings}),'enabledTextContrastMin':min(t['ratio']for r in settings for t in r['text']if not t.get('disabled')),'enabledControlBorderContrastMin':min(r['borderContrast']for r in settings if not r['disabled']),'focusRestoredOnSaveSuccessAndFailure':True},
 'glyphContrast':{theme:min(s['overlay']['glyphs']['contrast']for r in matrix if r['theme']==theme for s in r['snapshots']if s.get('overlay',{}) and s['overlay'].get('glyphs'))for theme in ['light','dark']},
 'visualInspection':['All 12 browser/theme/mode contact sheets','All four browser/theme settings contact sheets','Eight reduced-motion states','Final targeted horizontal-scroll early/middle/settled/end frames','Actual Chrome and Firefox Expand/Casino GIF sequence frames in both themes','Final two asset GIF early/middle/end frames'],
 'assets':gifs,
 'fixesPromptedByAudit':['Settings select lost focus while disabled for save; focus now restored without stealing from another control.','Native insertion scrolling canceled outline feedback; fixed. Native single-line input painting differs across browsers when horizontally scrolled or overflowing, so this compatibility case retains native text with outline only to avoid text jumps.'],
 'frozenSourceHashes':{f:hashlib.sha256((Path('/workspace/autocompletele/chrome-extension/src')/f).read_bytes()).hexdigest()for f in ['animation-frames.js','expansion-feedback.js','content.js']}
}
for asset in report['assets']:
 asset['copiedTo']=str(Path('/workspace/autocompletele/chrome-extension/store/images')/('actle-expansion.gif' if 'expand' in asset['file'] else 'actle-casino.gif'))
 a=Path(asset['copiedTo']); assert a.read_bytes()==(p/'final-gifs'/asset['file']).read_bytes(); asset['sha256']=hashlib.sha256(a.read_bytes()).hexdigest()
(p/'final-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
