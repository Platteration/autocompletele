const assert=require('node:assert/strict'),fs=require('node:fs'),http=require('node:http');
const {launch}=require('/workspace/autocompletele/chrome-extension/e2e/helper.js');
const demo=require('./demo.js');
const out=__dirname+'/gif-frames';fs.mkdirSync(out,{recursive:true});
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(demo('textarea',{trigger:'yg',neutralFocus:true}));});
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const app=await launch({shorthands:[{trigger:'yg',expansion:'you got it'}]});try{
 const page=app.page;await page.setViewportSize({width:760,height:560});await page.emulateMedia({colorScheme:'light',reducedMotion:'no-preference'});await page.goto(`http://127.0.0.1:${server.address().port}/`);
 const field=page.locator('#message');await field.focus();
 const session=await app.context.newCDPSession(page),frames=[];
 session.on('Page.screencastFrame',event=>{frames.push({data:event.data,time:event.metadata.timestamp});void session.send('Page.screencastFrameAck',{sessionId:event.sessionId});});
 await session.send('Page.startScreencast',{format:'png',everyNthFrame:1,maxWidth:760,maxHeight:560});
 await page.waitForTimeout(450);
 await field.pressSequentially('y',{delay:140});
 await page.waitForTimeout(380);
 await field.pressSequentially('g');
 assert.equal(await field.inputValue(),'you got it');
 assert.ok(await page.locator('#actle-expansion-feedback').count());
 await page.waitForTimeout(1100);
 await field.pressSequentially(' — keep typing.',{delay:65});
 assert.equal(await field.inputValue(),'you got it — keep typing.');
 assert.ok(await field.evaluate(e=>document.activeElement===e));
 await page.waitForTimeout(1250);
 await session.send('Page.stopScreencast');
 const times=[];for(let i=0;i<frames.length;i++){const name=`frame-${String(i).padStart(3,'0')}.png`;fs.writeFileSync(out+'/'+name,Buffer.from(frames[i].data,'base64'));times.push({file:name,seconds:frames[i].time-frames[0].time});}
 fs.writeFileSync(out+'/times.json',JSON.stringify(times,null,2));
 console.log(JSON.stringify({frames:frames.length,seconds:times.at(-1).seconds,viewport:{width:760,height:560},actualBrowserCapture:true}));
}finally{await app.close();await new Promise(resolve=>server.close(resolve));}})().catch(e=>{console.error(e);process.exitCode=1;});
