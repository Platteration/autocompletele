const assert=require('node:assert/strict'),fs=require('node:fs'),http=require('node:http');
const root='/workspace/autocompletele/chrome-extension',out=__dirname;
const demo=require('./demo.js');
const records=[];
const server=http.createServer((req,res)=>{res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(demo(new URL(req.url,'http://local').searchParams.get('type')||'textarea'));});
async function run(browser){
 const helper=require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js'));
 const app=await helper.launch();
 const page=app.page,driver=app.driver;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const wait=fn=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 const shot=async(file)=>{if(page)await page.screenshot({path:out+'/'+file});else fs.writeFileSync(out+'/'+file,Buffer.from(await driver.takeScreenshot(),'base64'));};
 const size=async(width,height)=>{if(page)await page.setViewportSize({width,height});else{await driver.manage().window().setRect({width,height});const extra=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:width+extra.w,height:height+extra.h});}};
 const get=()=>evaluate(()=>{const e=document.getElementById('message'),host=document.getElementById('actle-expansion-feedback'),r=e.getBoundingClientRect(),h=host?.getBoundingClientRect();return{now:performance.now(),value:e.isContentEditable?e.textContent:e.value,focused:document.activeElement===e,selection:e.isContentEditable?getSelection().anchorOffset:e.selectionStart,host:!!host,hostPointerEvents:host?getComputedStyle(host).pointerEvents:null,hostAriaHidden:host?.getAttribute('aria-hidden'),hostRect:h?{x:h.x,y:h.y,width:h.width,height:h.height}:null,fieldRect:{x:r.x,y:r.y,width:r.width,height:r.height},viewport:{width:innerWidth,height:innerHeight},overflow:document.documentElement.scrollWidth>innerWidth,reduced:matchMedia('(prefers-reduced-motion:reduce)').matches,events:window.__visualEvents};});
 try{
  for(const theme of ['light','dark'])for(const reduced of [false,true])for(const type of ['input','textarea','rich']){
   if(page)await page.emulateMedia({colorScheme:theme,reducedMotion:reduced?'reduce':'no-preference'});
   else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);Services.prefs.setIntPref("ui.prefersReducedMotion",arguments[1]);',theme==='dark'?1:0,reduced?1:0);await driver.setContext('content');}
   await size(browser==='chrome'?320:500,760);
   const url=`http://127.0.0.1:${server.address().port}/?type=${type}`;
   if(page)await page.goto(url);else await driver.get(url);
   await evaluate(()=>{
    window.__visualEvents=[];
    new MutationObserver(mutations=>{for(const m of mutations)for(const key of ['addedNodes','removedNodes'])for(const n of m[key])if(n.id==='actle-expansion-feedback')window.__visualEvents.push({action:key,time:performance.now()});}).observe(document.documentElement,{childList:true,subtree:true});
    document.getElementById('message').focus();
   });
   const field=page?page.locator('#message'):await app.element('#message');
   if(page)await field.pressSequentially('cool');else await field.sendKeys('cool');
   if(page)await field.pressSequentially('/');else await field.sendKeys('/');
   const immediate=await get();
   assert.equal(immediate.value,'That is really cool!');assert.ok(immediate.focused);assert.equal(immediate.reduced,reduced);assert.ok(!immediate.overflow);
   const id=`${browser}-${theme}-${type}-${reduced?'reduced':'motion'}`;
   const snapshots=[];
   if(reduced){assert.equal(immediate.host,false);await shot(id+'.png');snapshots.push({state:'reduced',...await get()});}
   else{
    assert.ok(immediate.host,id+' should show feedback');assert.equal(immediate.hostPointerEvents,'none');
    await shot(id+'-early.png');snapshots.push({state:'early',...await get()});
    const start=immediate.events.find(e=>e.action==='addedNodes')?.time||immediate.now;
    const now=await evaluate(()=>performance.now());await delay(Math.max(0,320-(now-start)));
    await shot(id+'-middle.png');snapshots.push({state:'middle',...await get()});
    await wait(()=>!document.getElementById('actle-expansion-feedback'));
    await shot(id+'-end.png');snapshots.push({state:'end',...await get()});
    assert.ok(!snapshots.at(-1).host);assert.equal(snapshots.at(-1).value,'That is really cool!');
    // Trigger once more and type while the cue is visible: typing must cancel it.
    await evaluate(()=>{const e=document.getElementById('message');if(e.isContentEditable)e.textContent='';else e.value='';e.focus();});
    if(page)await field.pressSequentially('cool/');else await field.sendKeys('cool/');
    assert.ok((await get()).host);
   }
   if(page)await field.pressSequentially(' Still typing.');else await field.sendKeys(' Still typing.');
   const continued=await get();assert.equal(continued.value,'That is really cool! Still typing.');assert.ok(continued.focused);assert.equal(continued.host,false);
   records.push({browser,theme,type,reduced,immediate,snapshots,continued});
   fs.writeFileSync(out+'/measurements.json',JSON.stringify(records,null,2));
   console.log(id+' passed');
  }
 }finally{await app.close();}
}
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));try{for(const browser of ['chrome','firefox'])await run(browser);console.log(JSON.stringify({cases:records.length,screenshots:records.reduce((sum,r)=>sum+r.snapshots.length,0),failures:0}));}finally{await new Promise(resolve=>server.close(resolve));}})().catch(e=>{console.error(e);process.exitCode=1;});
