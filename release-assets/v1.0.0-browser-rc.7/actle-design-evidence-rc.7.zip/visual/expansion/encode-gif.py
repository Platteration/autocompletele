from pathlib import Path
from PIL import Image
import json
p=Path(__file__).parent
records=json.loads((p/'gif-frames/times.json').read_text())
frames=[Image.open(p/'gif-frames'/r['file']).convert('RGB') for r in records]
# GIF encoding only: preserve the captured dimensions, positions and real timing.
# A shared palette reduces flicker between these real browser frames.
strip=Image.new('RGB',(frames[0].width,frames[0].height*min(12,len(frames))))
for i in range(min(12,len(frames))):strip.paste(frames[round(i*(len(frames)-1)/11)],(0,i*frames[0].height))
palette=strip.quantize(colors=256)
quantized=[f.quantize(palette=palette,dither=Image.Dither.NONE) for f in frames]
ticks=[round(r['seconds']*100)*10 for r in records]
durations=[max(10,ticks[i+1]-ticks[i]) if i+1<len(records) else 1300 for i in range(len(records))]
quantized[0].save(p/'actle-expansion-draft.gif',save_all=True,append_images=quantized[1:],duration=durations,loop=0,optimize=False,disposal=1)
print(json.dumps({'output':str(p/'actle-expansion-draft.gif'),'frames':len(frames),'durationMs':sum(durations),'sizeBytes':(p/'actle-expansion-draft.gif').stat().st_size}))
