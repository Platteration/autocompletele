const fs = require('node:fs');
const { launch } = require('/workspace/autocompletele/chrome-extension/e2e/helper.js');
(async () => {
  const app = await launch();
  const report = [];
  try {
    for (const theme of ['light', 'dark']) {
      for (const surface of ['options', 'popup']) {
        const page = await app.context.newPage();
        await page.emulateMedia({ colorScheme: theme, reducedMotion: 'no-preference' });
        await page.setViewportSize(surface === 'popup' ? {width:360, height:560} : {width:1280, height:800});
        await page.goto(`chrome-extension://${app.extensionId}/src/${surface}.html`);
        await page.locator('[data-actle-brand][data-actle-state="playing"]').waitFor();
        await page.evaluate(() => document.querySelector('.actle-brand__word').getAnimations({subtree:true}).forEach(a => { a.pause(); a.currentTime=1800; }));
        await page.screenshot({path:`/workspace/.onboarding/autocompletele/visual/actle/chrome-${surface}-${theme}-complete.png`});
        report.push(await page.evaluate(({theme,surface}) => {
          const brand=document.querySelector('[data-actle-brand]');
          const rect=brand.getBoundingClientRect();
          return {theme,surface,label:brand.getAttribute('aria-label'),width:rect.width,right:rect.right,viewport:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,addedColor:getComputedStyle(brand.querySelector('.actle-brand__completion')).color,baseColor:getComputedStyle(brand).color};
        },{theme,surface}));
        await page.emulateMedia({colorScheme:theme,reducedMotion:'reduce'});
        await page.waitForFunction(() => document.querySelector('[data-actle-brand]').dataset.actleState==='idle');
        await page.screenshot({path:`/workspace/.onboarding/autocompletele/visual/actle/chrome-${surface}-${theme}-rest.png`});
        await page.close();
      }
    }
    const page = await app.context.newPage();
    await page.setViewportSize({width:360,height:800});
    await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);
    await page.evaluate(() => document.querySelector('.actle-brand__word').getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=1800;}));
    await page.screenshot({path:'/workspace/.onboarding/autocompletele/visual/actle/chrome-options-narrow-complete.png'});
    report.push(await page.evaluate(() => ({surface:'narrowoptions',overflow:document.documentElement.scrollWidth>innerWidth,brandRight:document.querySelector('[data-actle-brand]').getBoundingClientRect().right})));
    console.log(JSON.stringify(report,null,2));
    fs.writeFileSync('/workspace/.onboarding/autocompletele/visual/actle/chrome-review.json',JSON.stringify(report,null,2));
  } finally { await app.close(); }
})().catch(e=>{console.error(e);process.exitCode=1});
