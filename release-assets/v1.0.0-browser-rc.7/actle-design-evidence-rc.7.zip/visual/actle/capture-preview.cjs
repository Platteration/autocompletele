const fs = require('node:fs');
const { launch } = require('/workspace/autocompletele/chrome-extension/e2e/helper.js');
(async () => {
  const app = await launch();
  const dir='/workspace/.onboarding/autocompletele/visual/actle/gif-frames';
  fs.mkdirSync(dir,{recursive:true});
  try {
    const page=await app.context.newPage();
    await page.emulateMedia({colorScheme:'light', reducedMotion:'no-preference'});
    await page.setViewportSize({width:360,height:560});
    await page.goto(`chrome-extension://${app.extensionId}/src/popup.html`);
    await page.locator('[data-actle-brand][data-actle-state="playing"]').waitFor();
    await page.evaluate(() => {
      self.previewAnimations = document.querySelector('.actle-brand__word').getAnimations({subtree:true});
      self.previewAnimations.forEach(a=>a.pause());
    });
    for(let i=0;i<=45;i++) {
      await page.evaluate(time => self.previewAnimations.forEach(a=>a.currentTime=time),i*80);
      await page.screenshot({path:`${dir}/frame-${String(i).padStart(3,'0')}.png`,clip:{x:0,y:0,width:240,height:80}});
    }
    console.log('Captured46 realbrowserframes at0–3600ms.');
  } finally {await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
