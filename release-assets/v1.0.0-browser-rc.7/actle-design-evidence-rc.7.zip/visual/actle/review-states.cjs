const {launch}=require('/workspace/autocompletele/chrome-extension/e2e/helper.js');
(async()=>{const app=await launch();try {
for(const theme of ['light','dark']) for(const surface of ['options','popup']) {
const page=await app.context.newPage();await page.emulateMedia({colorScheme:theme,reducedMotion:'no-preference'});await page.setViewportSize(surface==='popup'?{width:360,height:560}:{width:1280,height:800});await page.goto(`chrome-extension://${app.extensionId}/src/${surface}.html`);const brand=page.locator('[data-actle-brand]');await brand.waitFor();await page.evaluate(()=>document.querySelector('.actle-brand__word').getAnimations({subtree:true}).forEach(a=>{a.pause();a.currentTime=0;}));
const rect=await brand.boundingBox();const clip={x:rect.x-7,y:rect.y-7,width:rect.width+14,height:rect.height+14};
for(const state of ['hover','focus','pressed','reduced']) {
if(state==='hover')await brand.hover();
if(state==='focus'){await page.mouse.move(350,550);await page.keyboard.press('Tab');await brand.focus();}
if(state==='pressed'){await brand.hover();await page.mouse.down();}
if(state==='reduced'){await page.mouse.up();await page.emulateMedia({colorScheme:theme,reducedMotion:'reduce'});await page.waitForFunction(()=>document.querySelector('[data-actle-brand]').getAttribute('aria-disabled')==='true');await page.mouse.move(350,550);await page.locator('#search').focus();}
await page.screenshot({path:`/workspace/.onboarding/autocompletele/visual/actle/chrome-${surface}-${theme}-${state}.png`,clip});
}
await page.close();
}console.log('Captured16 interaction states.');
}finally{await app.close();}})().catch(e=>{console.error(e);process.exitCode=1});
