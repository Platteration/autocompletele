const fs=require('node:fs');
const assert=require('node:assert/strict');
const root='/workspace/autocompletele/chrome-extension';
const {launch}=require(root+'/e2e-firefox/helper.js');
(async()=>{
 const app=await launch();
 try {
  const {driver}=app;
  for(const theme of ['light','dark']) {
   await driver.setContext('chrome');
   await driver.executeScript('Services.prefs.setIntPref("layout.css.prefers-color-scheme.content-override",arguments[0]);',theme==='dark'?0:1);
   await driver.setContext('content');
   await app.openOptions();
   await driver.wait(async()=>await driver.executeScript('return matchMedia("(prefers-color-scheme:dark)").matches')===(theme==='dark'),5000);
   await app.fill('#pickerTrigger','has spaces');
   await (await app.element('#excluded')).click();
   await driver.wait(async()=>await app.text('#pickerMsg')==='The search trigger cannot contain spaces.',5000);
   const field=await app.element('#pickerTrigger');
   assert.equal(await field.getAttribute('aria-describedby'),'pickerMsg');
   assert.equal(await field.getAttribute('value'),';;');
   assert.equal(await app.text('#formMsg'),'');
   const geometry=await driver.executeScript('const f=document.getElementById("pickerTrigger").getBoundingClientRect();const m=document.getElementById("pickerMsg").getBoundingClientRect();return {gap:m.top-f.bottom,width:m.width,height:m.height}');
   assert.ok(geometry.gap>=0&&geometry.gap<=20&&geometry.width>0&&geometry.height>0,JSON.stringify(geometry));
   fs.writeFileSync(`/workspace/.onboarding/autocompletele/visual/firefox-picker-validation-${theme}.png`,Buffer.from(await (await app.element('#settings')).takeScreenshot(),'base64'));
   await app.fill('#pickerTrigger',';;');
   await (await app.element('#excluded')).click();
   await driver.wait(async()=>await app.text('#pickerMsg')==='',5000);
   console.log(theme,'local validation displayed with accessible description, reset to;;, then cleared for valid input',geometry);
  }
 } finally {await app.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
