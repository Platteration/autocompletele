const fs = require('node:fs');
const path = require('node:path');
const root = '/workspace/autocompletele/chrome-extension';
const out = '/workspace/.onboarding/autocompletele/visual/redesigned-options';
const { launch: launchChrome } = require(root + '/e2e/helper.js');
const { launch: launchFirefox, By, Key } = require(root + '/e2e-firefox/helper.js');
const snippets = [
 { trigger:'hello/', expansion:'Hi [[name]],\n\nThanks for reaching out about [[topic]]. I will send an update by [[date]].\n\nBest,\nAlex' },
 { trigger:'sig', expansion:'Alex' },
 { trigger:'sig/', expansion:'Best regards,\nAlex' },
 { trigger:'long-trigger-'.repeat(8)+'/', expansion:'LongExpansionWithoutSpaces'.repeat(6) },
];
const importer = path.join(out, 'sample-import.json');
fs.writeFileSync(importer, JSON.stringify({version:1,shorthands:[{trigger:'hello/',expansion:'Thanks again!'},{trigger:'new/',expansion:'A new shortcut'},{trigger:'',expansion:'Invalid item'}]}));
const results=[];
async function chrome() {
 const app=await launchChrome({shorthands:snippets});
 try {
  const page=await app.context.newPage();
  for(const theme of (process.env.AUDIT_THEME ? [process.env.AUDIT_THEME] : ['light','dark'])) {
   await app.worker.evaluate(items=>self.ShorthandStorage.replaceAll(items),snippets);
   await page.setViewportSize({width:1280,height:800});
   await page.emulateMedia({colorScheme:theme});
   await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);
   await page.waitForSelector('#list tbody tr');
   async function shot(state, selector) {
    const name=`chrome-options-${theme}-${state}.png`;
    const target=selector?page.locator(selector):page;
    await target.screenshot({path:path.join(out,name),...(selector?{}:{fullPage:state!=='desktop-viewport'})});
    results.push(name);
   }
   await page.locator('#list tbody tr').first().locator('button.secondary').click();
   await page.waitForSelector('#templatePreview .field-chip');
   await page.evaluate(()=>window.scrollTo(0,0));
   await shot('desktop-viewport');
   await shot('desktop');
   await shot('selected-editor','#editor');
   await page.setViewportSize({width:320,height:900});
   await shot('narrow320');
   await page.setViewportSize({width:1280,height:800});
   await page.locator('#expansion').focus(); await page.keyboard.press('Shift+Tab');
   await shot('focus','#editor');
   await page.locator('#saveBtn').hover();
   await shot('hover','#editor');
   await page.mouse.down(); await shot('pressed','#editor'); await page.mouse.move(0,0); await page.mouse.up();
   await page.fill('#trigger','sig/'); await page.fill('#expansion','A duplicate'); await page.click('#saveBtn');
   await page.waitForSelector('#formMsg.error'); await shot('error','#editor');
   await page.evaluate(()=>document.getElementById('saveBtn').disabled=true); await shot('disabled','#editor');
   await page.setInputFiles('#importFile',importer); await page.waitForSelector('#importPreview',{state:'visible'});
   await shot('import-preview','#importPreview');
   await app.worker.evaluate(()=>self.ShorthandStorage.replaceAll([])); await page.reload(); await page.waitForSelector('#empty',{state:'visible'});
   await shot('empty-library','#library');
  }
 } finally {await app.close();}
}
async function firefox() {
 const app=await launchFirefox();
 try {
  const {driver}=app;
  async function size(width,height) {
   await driver.manage().window().setRect({width,height});
   const extra=await driver.executeScript('return {width:outerWidth-innerWidth,height:outerHeight-innerHeight}');
   await driver.manage().window().setRect({width:width+extra.width,height:height+extra.height});
   return driver.executeScript('return {width:innerWidth,height:innerHeight}');
  }
  for(const theme of (process.env.AUDIT_THEME ? [process.env.AUDIT_THEME] : ['light','dark'])) {
   await driver.setContext('chrome');
   await driver.executeScript('Services.prefs.setIntPref("layout.css.prefers-color-scheme.content-override", arguments[0]);',theme==='dark'?0:1);
   await driver.setContext('content');
   await driver.switchTo().window(app.optionsHandle);
   await driver.get(`${app.extensionURL}/src/options.html`);
   await driver.executeScript(items=>self.ShorthandStorage.replaceAll(items),snippets);
   await driver.navigate().refresh();
   await driver.wait(async()=>await driver.executeScript('return document.querySelectorAll("#list tbody tr").length===4'),5000);
   await driver.wait(async()=>await driver.executeScript('return matchMedia("(prefers-color-scheme:dark)").matches')===(theme==='dark'),5000);
   async function shot(state,selector) {
    const name=`firefox-options-${theme}-${state}.png`;
    const data=selector?await (await driver.findElement(By.css(selector))).takeScreenshot():state==='desktop-viewport'?await driver.takeScreenshot():await driver.takeFullPageScreenshot();
    fs.writeFileSync(path.join(out,name),Buffer.from(data,'base64'));
    results.push(name);
   }
   await size(1280,800);
   await (await app.element('#list tbody tr:first-child button.secondary')).click();
   await driver.wait(async()=>await driver.executeScript('return document.querySelectorAll("#templatePreview .field-chip").length===3'),5000);
   await driver.executeScript('window.scrollTo(0,0)');
   await shot('desktop-viewport');
   await shot('desktop'); await shot('selected-editor','#editor');
   console.log('Firefox narrow viewport',theme,await size(500,900));
   console.log('Firefox accessible roles',theme,await (await app.element('#list')).getAriaRole(),await (await app.element('#list tbody tr')).getAriaRole(),await (await app.element('#list tbody td')).getAriaRole());
   await shot('narrow500');
   await size(1280,800);
   await (await app.element('#expansion')).sendKeys(Key.chord(Key.SHIFT,Key.TAB)); await shot('focus','#editor');
   const save=await app.element('#saveBtn');
   await driver.actions({async:true}).move({origin:save}).perform(); await shot('hover','#editor');
   await driver.actions({async:true}).press().perform(); await shot('pressed','#editor'); await driver.actions({async:true}).move({x:0,y:0}).release().perform();
   await app.fill('#trigger','sig/'); await app.fill('#expansion','A duplicate'); await save.click();
   await driver.wait(async()=>await driver.executeScript('return document.querySelector("#formMsg.error")!==null'),5000); await shot('error','#editor');
   await driver.executeScript('document.getElementById("saveBtn").disabled=true'); await shot('disabled','#editor');
   await (await app.element('#importFile')).sendKeys(importer);
   await driver.wait(async()=>await driver.executeScript('return !document.getElementById("importPreview").hidden'),5000); await shot('import-preview','#importPreview');
   await driver.executeScript('return self.ShorthandStorage.replaceAll([])'); await driver.navigate().refresh();
   await driver.wait(async()=>await driver.executeScript('return !document.getElementById("empty").hidden'),5000); await shot('empty-library','#library');
  }
 } finally {await app.close();}
}
(async()=>{if(process.env.AUDIT_BROWSER!=='firefox') await chrome();await firefox();fs.writeFileSync(path.join(out,'capture-options.json'),JSON.stringify({screenshots:results,disabled:'Save button disabled directly as supplementary CSS state proof; no saving behavior is claimed.'},null,2));console.log('Captured',results.length,'screenshots');})().catch(e=>{console.error(e);process.exitCode=1;});
