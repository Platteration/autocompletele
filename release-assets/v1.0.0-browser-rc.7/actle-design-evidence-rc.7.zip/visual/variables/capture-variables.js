const fs=require('node:fs');
const assert=require('node:assert/strict');
const root='/workspace/autocompletele/chrome-extension';
const out='/workspace/.onboarding/autocompletele/visual/variables';
const measure=require(out+'/measure.js');
const rich='Hi [[name]],\n\nYour [[item]] is ready this {weekday}. Please share it with {object}.\n{Subject} will follow up with you, [[name]].\n\nThanks,\nAlex';
const results=[];
async function run(browser){
 const app=await require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')).launch();
 let page,driver=app.driver;
 if(browser==='chrome') page=await app.context.newPage();
 const evaluate=(fn,arg)=>browser==='chrome'?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const size=async(width,height)=>{if(page)await page.setViewportSize({width,height});else{await driver.manage().window().setRect({width,height});const extra=await evaluate(()=>({width:outerWidth-innerWidth,height:outerHeight-innerHeight}));await driver.manage().window().setRect({width:width+extra.width,height:height+extra.height});}};
 const set=async(selector,value)=>evaluate(({selector,value})=>{const el=window.__visualRoot.querySelector(selector);el.value=value;el.dispatchEvent(new Event(el.tagName==='SELECT'?'change':'input',{bubbles:true}));},{selector,value});
 const click=selector=>evaluate(selector=>window.__visualRoot.querySelector(selector).click(),selector);
 const wait=async(fn)=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 async function shot(theme,state,selector){
  const file=`${browser}-${theme}-${state}.png`;
  if(page){if(selector)await page.locator(selector).screenshot({path:out+'/'+file});else await page.screenshot({path:out+'/'+file});}
  else{const data=selector?await(await app.element(selector)).takeScreenshot():await driver.takeScreenshot();fs.writeFileSync(out+'/'+file,Buffer.from(data,'base64'));}
  const measured=await evaluate(measure);results.push({browser,theme,state,file,...measured});
  assert.ok(measured.panel.left>=0&&measured.panel.right<=measured.viewport.width,JSON.stringify(measured.panel));
 }
 try{
  for(const theme of ['light','dark']){
   if(page){await page.emulateMedia({colorScheme:theme});await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);await page.waitForSelector('#list tbody tr');}
   else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);',theme==='dark'?1:0);await driver.setContext('content');await app.openOptions();}
   await size(1280,900);
   await evaluate(()=>{const original=Element.prototype.attachShadow;Element.prototype.attachShadow=function(options){const shadow=original.call(this,options);if(this.id==='shorthand-template-host')window.__visualRoot=shadow;return shadow;};});
   await evaluate(expansion=>{window.__visualMode='normal';window.ShorthandTemplateForm.show({trigger:'update/',expansion,onSubmit:async rendered=>{window.__visualRendered=rendered;if(window.__visualMode==='busy')return new Promise(resolve=>window.__visualRelease=resolve);return undefined;}});},rich);
   await shot(theme,'fields-empty');
   await click('#template-submit');await shot(theme,'required');
   await set('#template-field-0','Morgan');await set('#template-field-1','design brief');await set('#template-pronouns','they/them');
   await shot(theme,'fields-filled');
   await click('#template-view-message');await shot(theme,'inline-filled');
   await evaluate(()=>{const list=window.__visualRoot.querySelectorAll('.inline-input[data-field-name="name"]');list[1].focus();list[1].value='Riley';list[1].dispatchEvent(new Event('input',{bubbles:true}));});
   assert.deepEqual(await evaluate(()=>[...window.__visualRoot.querySelectorAll('[data-field-name="name"]')].map(e=>e.value)),['Riley','Riley','Riley']);
   await shot(theme,'inline-repeat-focus');
   const point=await evaluate(()=>{const r=window.__visualRoot.querySelector('.submit').getBoundingClientRect();return{x:Math.round(r.left+r.width/2),y:Math.round(r.top+r.height/2)};});
   if(page)await page.mouse.move(point.x,point.y);else await driver.actions({async:true}).move(point).perform();
   await shot(theme,'hover');
   if(page)await page.mouse.down();else await driver.actions({async:true}).press().perform();
   await shot(theme,'pressed');
   if(page){await page.mouse.move(0,0);await page.mouse.up();}else await driver.actions({async:true}).move({x:0,y:0}).release().perform();
   await set('#template-pronouns','custom');await click('#template-submit');await shot(theme,'custom-required');
   await set('#template-pronoun-object','zir');await set('#template-pronoun-subject','ze');await shot(theme,'custom-filled');
   await evaluate(()=>window.__visualMode='busy');await click('#template-submit');await wait(()=>window.__visualRoot.querySelector('form').getAttribute('aria-busy')==='true');
   assert.ok(await evaluate(()=>[...window.__visualRoot.querySelectorAll('input,select,button')].every(e=>e.disabled)));
   await shot(theme,'busy');
   await evaluate(()=>window.__visualRelease('The insertion target is unavailable. Your answers are still here.'));await wait(()=>window.__visualRoot.querySelector('form').getAttribute('aria-busy')==='false');await shot(theme,'error');
   await set('#template-pronouns','they/them');
   await size(browser==='chrome'?320:500,900);await shot(theme,'narrow-inline');
   await click('#template-view-fields');await shot(theme,'narrow-table');
   await evaluate(()=>{window.ShorthandTemplateForm.close();window.__visualRoot=document.getElementById('editor');});
   await size(1280,800);
   await evaluate(expansion=>{const e=document.getElementById('expansion');document.getElementById('trigger').value='update/';e.value=expansion;e.dispatchEvent(new Event('input',{bubbles:true}));},rich);
   await shot(theme,'editor','#editor');
  }
 }finally{await app.close();}
}
(async()=>{for(const browser of ['chrome','firefox'])await run(browser);fs.writeFileSync(out+'/measurements.json',JSON.stringify(results,null,2));const failures=results.flatMap(r=>[...r.text.filter(t=>!t.disabled&&t.ratio<4.5).map(t=>({browser:r.browser,theme:r.theme,state:r.state,...t})),...r.controls.filter(c=>c.ratio<3).map(c=>({browser:r.browser,theme:r.theme,state:r.state,control:true,...c}))]);console.log(JSON.stringify({captures:results.length,minText:Math.min(...results.map(r=>r.minimumText)),minControl:Math.min(...results.flatMap(r=>r.controls.map(c=>c.ratio))),failures},null,2));if(failures.length)process.exitCode=1;})().catch(e=>{console.error(e);fs.writeFileSync(out+'/measurements-partial.json',JSON.stringify(results,null,2));process.exitCode=1;});
