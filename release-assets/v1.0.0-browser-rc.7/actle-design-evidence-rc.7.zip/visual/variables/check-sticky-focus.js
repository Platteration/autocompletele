const fs=require('node:fs');
const assert=require('node:assert/strict');
const root='/workspace/autocompletele/chrome-extension';
const{SNIPPETS}=require(root+'/scripts/store-assets.js');
const reports=[];
(async()=>{for(const browser of ['chrome','firefox']){
 const app=await require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')).launch({shorthands:SNIPPETS});
 try{
  const page=browser==='chrome'?await app.context.newPage():null,driver=app.driver;
  const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
  if(page){await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);await page.waitForSelector('#list tbody tr');}else{await app.openOptions();await evaluate(items=>self.ShorthandStorage.replaceAll(items),SNIPPETS);await driver.navigate().refresh();}
  await evaluate(()=>document.querySelector('#list tbody tr button.secondary').click());
  for(const width of [1280,961,browser==='chrome'?320:500]){
   if(page)await page.setViewportSize({width,height:800});else{await driver.manage().window().setRect({width,height:800});const extra=await evaluate(()=>({width:outerWidth-innerWidth,height:outerHeight-innerHeight}));await driver.manage().window().setRect({width:width+extra.width,height:800+extra.height});}
   const result=await evaluate(()=>{
    window.scrollTo(0,0);const actions=document.querySelector('#editor>.actions');const r=document.getElementById('saveBtn').getBoundingClientRect();
    const report={viewport:{width:innerWidth,height:innerHeight},position:getComputedStyle(actions).position,save:{top:r.top,bottom:r.bottom},controls:[]};
    for(const control of document.querySelectorAll('#editor input,#editor textarea,#editor select,#editor button')){
     if(!control.getClientRects().length||control.disabled)continue;
     control.focus();const c=control.getBoundingClientRect(),bar=actions.getBoundingClientRect();
     const hiddenByBar=!actions.contains(control)&&c.top<bar.bottom&&c.bottom>bar.top;
     report.controls.push({id:control.id||control.textContent,top:c.top,bottom:c.bottom,hiddenByBar,visible:c.top>=0&&c.bottom<=innerHeight});
    }
    const preview=document.getElementById('templatePreview');preview.scrollIntoView({block:'center'});preview.scrollTop=preview.scrollHeight;
    const p=preview.getBoundingClientRect(),bar=actions.getBoundingClientRect();report.preview={top:p.top,bottom:p.bottom,hiddenByBar:p.top<bar.bottom&&p.bottom>bar.top,atEnd:preview.scrollTop+preview.clientHeight>=preview.scrollHeight};
    return report;
   });
   reports.push({browser,...result});
   if(width>=961)assert.ok(result.save.bottom<=800,`${browser}${width} save belowfold: ${JSON.stringify(result.save)}`);
   assert.deepEqual(result.controls.filter(c=>c.hiddenByBar||!c.visible),[],`${browser}${width} focused control obscured`);
   assert.ok(!result.preview.hiddenByBar&&result.preview.atEnd,`${browser}${width} preview not fully reachable`);
  }
 }finally{await app.close();}
}fs.writeFileSync('/workspace/.onboarding/autocompletele/visual/variables/sticky-focus-final.json',JSON.stringify(reports,null,2));console.log('All focused controls and the full preview remain reachable in both browsers at1280,961,and narrow widths.');})().catch(e=>{console.error(e);fs.writeFileSync('/workspace/.onboarding/autocompletele/visual/variables/sticky-focus-partial.json',JSON.stringify(reports,null,2));process.exitCode=1});
