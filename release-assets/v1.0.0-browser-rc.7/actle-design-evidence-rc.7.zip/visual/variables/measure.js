// Read-only rendered measurements for the real extension's captured closed root.
module.exports = function measure() {
  const root = window.__visualRoot || document;
  const canvas = document.createElement('canvas'); canvas.width=canvas.height=1;
  const context=canvas.getContext('2d',{willReadFrequently:true});
  const color=value=>{context.clearRect(0,0,1,1);context.fillStyle=value;context.fillRect(0,0,1,1);const c=[...context.getImageData(0,0,1,1).data];return[c[0],c[1],c[2],c[3]/255];};
  const over=(front,back)=>front.slice(0,3).map((c,i)=>c*front[3]+back[i]*(1-front[3]));
  const luminance=c=>c.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4;}).reduce((s,c,i)=>s+c*[.2126,.7152,.0722][i],0);
  const ratio=(a,b)=>{const x=luminance(a),y=luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
  function background(element){const parents=[];for(let e=element;e;e=e.parentElement||e.getRootNode().host)parents.unshift(e);return parents.reduce((c,e)=>{const style=getComputedStyle(e);const value=style.backgroundImage.startsWith('linear-gradient')?style.getPropertyValue('--soft').trim():style.backgroundColor;return over(color(value),c);},[255,255,255]);}
  const texts=[];
  for(const element of root.querySelectorAll('input,select,button,th,td,label,p,h2,h3,span,code')){
    if(!element.getClientRects().length)continue;
    const input=element.matches('input');
    let text=input?(element.value||element.placeholder):element.matches('select')?element.selectedOptions[0]?.textContent:[...element.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join('');
    if(!text?.trim())continue;
    const bg=background(element);const style=getComputedStyle(element,input&&!element.value?'::placeholder':null);
    texts.push({selector:element.id||element.className||element.tagName,text:text.trim().slice(0,70),ratio:ratio(over(color(style.color),bg),bg),disabled:element.disabled===true});
  }
  const controls=[...root.querySelectorAll('input,select')].filter(e=>e.getClientRects().length&&!e.disabled).map(e=>({selector:e.id||e.className||e.tagName,ratio:ratio(color(getComputedStyle(e).borderTopColor).slice(0,3),background(e))}));
  const panel=root.querySelector('.panel')||document.getElementById('editor');
  const box=panel.getBoundingClientRect();
  return {theme:matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light',viewport:{width:innerWidth,height:innerHeight},panel:{left:box.left,right:box.right,top:box.top,bottom:box.bottom},text:texts,controls,minimumControl:Math.min(...controls.map(c=>c.ratio)),minimumText:Math.min(...texts.filter(t=>!t.disabled).map(t=>t.ratio)),overflow:[...root.querySelectorAll('input,select,button,.inline-message,.field-table')].filter(e=>e.getClientRects().length).map(e=>({selector:e.id||e.className||e.tagName,left:e.getBoundingClientRect().left,right:e.getBoundingClientRect().right})).filter(r=>r.left<box.left||r.right>box.right)};
};
