// Read-only inspection of actual browser-rendered elements, including closed roots.
function inspect(panel) {
  const root=panel.getRootNode(),canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');
  const rgba=value=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=value;ctx.fillRect(0,0,1,1);const c=[...ctx.getImageData(0,0,1,1).data];return[...c.slice(0,3),c[3]/255];};
  const over=(a,b)=>a.slice(0,3).map((v,i)=>v*a[3]+b[i]*(1-a[3]));
  const background=e=>{const nodes=[];for(;e;e=e.parentElement||e.getRootNode().host)nodes.unshift(e);return nodes.reduce((color,node)=>over(rgba(getComputedStyle(node).backgroundColor),color),[255,255,255]);};
  const lum=color=>color.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0);
  const ratio=(a,b)=>{const[x,y]=[lum(a),lum(b)];return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
  const box=e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height,left:r.left,right:r.right,top:r.top,bottom:r.bottom};};
  const describe=e=>{const s=getComputedStyle(e),bg=background(e);return{tag:e.tagName,class:e.className,text:e.textContent,rect:box(e),color:s.color,background:s.backgroundColor,resolvedBackground:bg,contrast:ratio(over(rgba(s.color),bg),bg),opacity:s.opacity,font:s.font,lineHeight:s.lineHeight,outline:{width:s.outlineWidth,color:s.outlineColor,style:s.outlineStyle},border:{color:s.borderLeftColor,width:s.borderLeftWidth,contrast:ratio(over(rgba(s.borderLeftColor),bg),bg)},scrollWidth:e.scrollWidth,clientWidth:e.clientWidth,hover:e.matches(':hover'),active:e.matches(':active'),selected:e.getAttribute('aria-selected')||e.dataset.selected};};
  const leaves=[...panel.querySelectorAll('*')].filter(e=>e.getClientRects().length&&e.textContent.trim()&&(!e.children.length||[...e.childNodes].some(n=>n.nodeType===3&&n.textContent.trim())));
  return{panel:describe(panel),items:[...root.querySelectorAll('[role=option]')].map(describe),text:leaves.map(describe),viewport:{width:innerWidth,height:innerHeight},documentOverflow:document.documentElement.scrollWidth>innerWidth,focused:document.activeElement?.id||document.activeElement?.tagName,editorValue:document.getElementById('message')?.value,mediaDark:matchMedia('(prefers-color-scheme: dark)').matches};
}
module.exports={inspect,readPanel:async function(app,session,By){
  if(session){
    const{root}=await session.send('DOM.getDocument',{depth:-1,pierce:true});let found;
    const walk=node=>{if(found)return;const a=node.attributes||[],i=a.indexOf('id');if(i>=0&&a[i+1]==='actle-suggestions-host'){found=node;return;}for(const child of [...node.children||[],...node.shadowRoots||[]])walk(child);};walk(root);
    if(!found)return null;
    const shadow=found.shadowRoots?.[0];if(!shadow)throw Error('Expected closed suggestion shadow root');
    const{object}=await session.send('DOM.resolveNode',{backendNodeId:shadow.backendNodeId});
    try{const{result,exceptionDetails}=await session.send('Runtime.callFunctionOn',{objectId:object.objectId,functionDeclaration:'function(){return ('+inspect.toString()+')(this.querySelector(".panel"));}',returnByValue:true});if(exceptionDetails)throw Error(exceptionDetails.text);return result.value;}finally{await session.send('Runtime.releaseObject',{objectId:object.objectId});}
  }
  const hosts=await app.driver.findElements(By.css('#actle-suggestions-host'));if(!hosts.length)return null;
  const shadow=await hosts[0].getShadowRoot(),panel=await shadow.findElement(By.css('.panel'));
  return app.driver.executeScript(inspect,panel);
}};
