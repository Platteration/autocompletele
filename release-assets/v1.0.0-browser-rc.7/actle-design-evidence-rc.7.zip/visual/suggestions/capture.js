const assert=require('node:assert/strict'),fs=require('node:fs'),http=require('node:http');
const root='/workspace/autocompletele/chrome-extension',out=__dirname;
const {readPanel}=require('./inspect.js'),{entries,css,html}=require('./fixture.js');
const records=[];const delay=ms=>new Promise(r=>setTimeout(r,ms));
const server=http.createServer((req,res)=>{const strict=req.url.startsWith('/strict');res.writeHead(200,{'Content-Type':req.url==='/fixture.css'?'text/css; charset=utf-8':'text/html; charset=utf-8',...(strict?{'Content-Security-Policy':"default-src 'none'; style-src 'none'; script-src 'none'; img-src 'none'"}:{})});res.end(req.url==='/fixture.css'?css:strict?'<!doctype html><html><meta charset="utf-8"><title>Strict CSP suggestion preview</title><body><label for="message">Message</label><textarea id="message"></textarea></body></html>':html);});
async function run(browser){
 const helper=require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')),app=await helper.launch({shorthands:entries,settings:{suggestionsEnabled:true}});
 const page=app.page,driver=app.driver,session=page?await app.context.newCDPSession(page):null;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const wait=fn=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 const key=async name=>{if(page)await page.keyboard.press(name);else await driver.actions().sendKeys(helper.Key[{ArrowDown:'ARROW_DOWN',ArrowUp:'ARROW_UP',Escape:'ESCAPE',Enter:'ENTER',Tab:'TAB'}[name]]||name).perform();};
 const type=async text=>{if(page)await page.locator('#message').pressSequentially(text);else await(await app.element('#message')).sendKeys(text);};
 const size=async(width,height)=>{if(page)await page.setViewportSize({width,height});else{await driver.manage().window().setRect({width,height});const d=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:width+d.w,height:height+d.h});}};
 const move=async rect=>{const x=Math.round(rect.x+Math.min(30,rect.width/2)),y=Math.round(rect.y+rect.height/2);if(page)await page.mouse.move(x,y);else await driver.actions().move({x,y,origin:'viewport'}).perform();};
 const pointer=async action=>{if(page)await page.mouse[action]();else await driver.actions()[action==='down'?'press':'release']().perform();};
 const seed=async list=>{if(page)await app.worker.evaluate(list=>self.ShorthandStorage.replaceAll(list),list);else{await driver.switchTo().window(app.optionsHandle);await driver.executeScript(list=>self.ShorthandStorage.replaceAll(list),list);await driver.switchTo().window(app.fixtureHandle);}};
 const setting=async patch=>{if(page)await app.worker.evaluate(p=>self.ShorthandStorage.saveSettings(p),patch);else{await app.settings(patch);await driver.switchTo().window(app.fixtureHandle);}};
 const open=async path=>{const url=`http://127.0.0.1:${server.address().port}/${path||''}`;if(page)await page.goto(url);else await driver.get(url);await evaluate(()=>{window.__visualInputs=[];window.__visualCsp=[];document.getElementById('message').addEventListener('input',event=>window.__visualInputs.push({value:event.target.value,trusted:event.isTrusted}));document.addEventListener('securitypolicyviolation',event=>window.__visualCsp.push({directive:event.violatedDirective,blocked:event.blockedURI}));});await delay(150);};
 const capture=async(theme,state,{panelExpected=true}={})=>{
   const file=`${browser}-${theme}-${state}.png`;if(page)await page.screenshot({path:out+'/'+file});else fs.writeFileSync(out+'/'+file,Buffer.from(await driver.takeScreenshot(),'base64'));
   const panel=await readPanel(app,session,helper.By),documentState=await evaluate(()=>({active:document.activeElement?.id,value:document.getElementById('message').value,inputs:window.__visualInputs,csp:window.__visualCsp,viewport:{width:innerWidth,height:innerHeight},overflow:document.documentElement.scrollWidth>innerWidth}));
   assert.equal(!!panel,panelExpected,state+' visibility');assert.equal(documentState.overflow,false,state+' page overflow');
   if(panel){assert.equal(panel.focused,'message',state+' native focus');assert.ok(panel.panel.rect.left>=0&&panel.panel.rect.right<=panel.viewport.width,state+' panel horizontal bounds');assert.ok(panel.panel.rect.top>=0&&panel.panel.rect.bottom<=panel.viewport.height,state+' panel vertical bounds');assert.ok(panel.panel.scrollWidth<=panel.panel.clientWidth,state+' panel inner overflow');assert.ok(panel.text.length);assert.ok(panel.text.every(t=>t.contrast>=4.5),state+' text contrast '+JSON.stringify(panel.text));assert.ok(panel.items.length<=5);for(const item of panel.items)assert.ok(item.rect.left>=panel.panel.rect.left&&item.rect.right<=panel.panel.rect.right,state+' row bounds');}
   records.push({browser,theme,state,file,panel,documentState});fs.writeFileSync(out+'/panel-metrics.json',JSON.stringify(records,null,2));console.log(`${browser} ${theme} ${state}`);return panel;
 };
 try{
  if(!page){await seed(entries);await app.settings({suggestionsEnabled:true});await driver.switchTo().window(app.fixtureHandle);}
  for(const theme of ['light','dark']){
   if(page)await page.emulateMedia({colorScheme:theme});else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);',theme==='dark'?1:0);await driver.setContext('content');}
   await size(980,840);await seed(entries);await open();await capture(theme,'empty',{panelExpected:false});
   await type('co');await wait(()=>!!document.getElementById('actle-suggestions-host'));let panel=await capture(theme,'visible');assert.ok(panel.items.every(i=>i.selected!=='true'),'No initially selected result');assert.equal(panel.editorValue,'co');
   await key('ArrowDown');panel=await capture(theme,'keyboard-selected');assert.equal(panel.items.filter(i=>i.selected==='true').length,1);assert.ok(panel.items.find(i=>i.selected==='true').border.contrast>=3,'selection indicator contrast');
   await move(panel.items[1].rect);panel=await capture(theme,'hover');assert.ok(panel.items[1].hover,'Trusted hover target');
   await pointer('down');await capture(theme,'pressed',{panelExpected:!!await evaluate(()=>document.getElementById('actle-suggestions-host'))});await pointer('up');
   await open();await type('xy');await capture(theme,'no-results',{panelExpected:false});
   await size(browser==='chrome'?320:500,840);await open();await type('co');await wait(()=>!!document.getElementById('actle-suggestions-host'));await capture(theme,'narrow');
   await seed([entries[5]]);await open();await type('co');await wait(()=>!!document.getElementById('actle-suggestions-host'));await capture(theme,'long-preview');
   await seed(entries);await size(980,840);await open('strict');await type('co');await wait(()=>!!document.getElementById('actle-suggestions-host'));await capture(theme,'strict-csp');
   await setting({suggestionsEnabled:false});await open();await type('co');await capture(theme,'setting-off',{panelExpected:false});await setting({suggestionsEnabled:true});
  }
 }finally{await app.close();}
}
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));try{for(const browser of (process.argv.slice(2).length?process.argv.slice(2):['chrome','firefox']))await run(browser);console.log(JSON.stringify({captures:records.length,minText:Math.min(...records.flatMap(r=>r.panel?r.panel.text.map(t=>t.contrast):[]))}));}finally{await new Promise(resolve=>server.close(resolve));}})().catch(e=>{console.error(e);process.exitCode=1;});
