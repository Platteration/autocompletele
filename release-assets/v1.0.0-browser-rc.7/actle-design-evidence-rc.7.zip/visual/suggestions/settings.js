const assert=require('node:assert/strict'),fs=require('node:fs');
const root='/workspace/autocompletele/chrome-extension',out=__dirname,records=[];
async function run(browser){
 const helper=require(root+(browser==='chrome'?'/e2e/helper.js':'/e2e-firefox/helper.js')),app=await helper.launch();
 const page=app.page,driver=app.driver;
 const evaluate=(fn,arg)=>page?page.evaluate(fn,arg):driver.executeScript(fn,arg);
 const wait=fn=>page?page.waitForFunction(fn):driver.wait(()=>driver.executeScript(fn),5000);
 const toggle=async()=>{if(page)await page.locator('#suggestionsEnabled').click();else await(await app.element('#suggestionsEnabled')).click();};
 const shot=async(theme,state)=>{
  const file=`${browser}-${theme}-settings-${state}.png`;
  if(page)await page.locator('#suggestionsEnabled').locator('../..').screenshot({path:out+'/'+file});
  else fs.writeFileSync(out+'/'+file,Buffer.from(await(await app.element('#suggestionsEnabled')).findElement(helper.By.xpath('../..')).takeScreenshot(),'base64'));
  const data=await evaluate(()=>{
   const control=document.getElementById('suggestionsEnabled'),row=control.parentElement.parentElement,box=row.getBoundingClientRect(),style=getComputedStyle(control);
   const color=v=>{const c=document.createElement('canvas').getContext('2d');c.fillStyle=v;c.fillRect(0,0,1,1);const rgba=[...c.getImageData(0,0,1,1).data];return[...rgba.slice(0,3),rgba[3]/255];};
   const blend=(f,b)=>f.slice(0,3).map((v,i)=>v*f[3]+b[i]*(1-f[3]));
   const bg=e=>{const ancestors=[];for(;e;e=e.parentElement)ancestors.unshift(e);return ancestors.reduce((v,e)=>blend(color(getComputedStyle(e).backgroundColor),v),[255,255,255]);};
   const lum=v=>v.map(x=>{x/=255;return x<=.04045?x/12.92:((x+.055)/1.055)**2.4;}).reduce((s,x,i)=>s+x*[.2126,.7152,.0722][i],0);
   const ratio=(a,b)=>{const[x,y]=[lum(a),lum(b)];return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
   const text=[...row.querySelectorAll('strong,small,#suggestionsMsg')].filter(e=>e.getClientRects().length&&e.textContent.trim()).map(e=>{const background=bg(e),s=getComputedStyle(e);return{id:e.id||e.tagName,color:s.color,background,ratio:ratio(blend(color(s.color),background),background)};});
   return{checked:control.checked,disabled:control.disabled,focused:document.activeElement===control,hover:control.matches(':hover'),active:control.matches(':active'),outline:{style:style.outlineStyle,width:style.outlineWidth,color:style.outlineColor,ratio:ratio(color(style.outlineColor).slice(0,3),bg(control.parentElement))},message:document.getElementById('suggestionsMsg').textContent,knobContrast:ratio(color(getComputedStyle(control,'::before').backgroundColor).slice(0,3),bg(control)),borderContrast:ratio(color(style.borderTopColor).slice(0,3),bg(control.parentElement)),text,box:{left:box.left,right:box.right},viewport:{width:innerWidth,height:innerHeight},overflow:document.documentElement.scrollWidth>innerWidth};
  });
  records.push({browser,theme,state,file,...data});fs.writeFileSync(out+'/settings-metrics-'+browser+'.json',JSON.stringify(records,null,2));
  assert.ok(data.box.left>=0&&data.box.right<=data.viewport.width);assert.equal(data.overflow,false);if(state==='focused'){assert.ok(data.focused);assert.ok(parseFloat(data.outline.width)>0);assert.ok(data.outline.ratio>=3);}if(!data.disabled)assert.ok(data.knobContrast>=3);assert.ok(data.text.every(t=>t.ratio>=4.5),JSON.stringify(data.text));fs.writeFileSync(out+'/settings-metrics.json',JSON.stringify(records,null,2));console.log(`${browser} ${theme} settings ${state}`);
 };
 try{
  for(const theme of ['light','dark']){
   if(page){await page.setViewportSize({width:320,height:900});await page.emulateMedia({colorScheme:theme});await app.worker.evaluate(()=>self.ShorthandStorage.saveSettings({suggestionsEnabled:true}));await page.goto(`chrome-extension://${app.extensionId}/src/options.html`);await page.waitForSelector('#suggestionsEnabled');}
   else{await driver.setContext('chrome');await driver.executeScript('Services.prefs.setIntPref("ui.systemUsesDarkTheme",arguments[0]);',theme==='dark'?1:0);await driver.setContext('content');await app.openOptions();await evaluate(()=>self.ShorthandStorage.saveSettings({suggestionsEnabled:true}));await app.openOptions();await driver.manage().window().setRect({width:500,height:900});const d=await evaluate(()=>({w:outerWidth-innerWidth,h:outerHeight-innerHeight}));await driver.manage().window().setRect({width:500+d.w,height:900+d.h});}
   await evaluate(()=>document.getElementById('suggestionsEnabled').scrollIntoView({block:'center'}));await shot(theme,'on');
   if(page){await page.locator('#suggestionsEnabled').focus();await page.keyboard.press('Tab');await page.keyboard.press('Shift+Tab');}
   else{await evaluate(()=>document.getElementById('suggestionsEnabled').focus());await driver.actions().sendKeys(helper.Key.TAB).keyDown(helper.Key.SHIFT).sendKeys(helper.Key.TAB).keyUp(helper.Key.SHIFT).perform();}
   await shot(theme,'focused');
   if(page)await page.locator('#suggestionsEnabled').hover();else await driver.actions().move({origin:await app.element('#suggestionsEnabled')}).perform();await shot(theme,'hover');
   if(page)await page.mouse.down();else await driver.actions().press().perform();await shot(theme,'pressed');if(page)await page.mouse.up();else await driver.actions().release().perform();
   await wait(()=>!document.getElementById('suggestionsEnabled').disabled&&document.getElementById('suggestionsMsg').textContent.includes('saved: off'));await shot(theme,'saved-off');
   await evaluate(()=>{window.__realSuggestionSave=self.ShorthandStorage.saveSettings;self.ShorthandStorage.saveSettings=()=>new Promise((resolve,reject)=>{window.__visualReject=reject;});});
   await toggle();await wait(()=>document.getElementById('suggestionsEnabled').disabled);await shot(theme,'pending-disabled');
   await evaluate(()=>window.__visualReject(new Error('Connection interrupted')));await wait(()=>!document.getElementById('suggestionsEnabled').disabled&&document.getElementById('suggestionsMsg').classList.contains('error'));await shot(theme,'save-error');assert.equal(await evaluate(()=>document.getElementById('suggestionsEnabled').checked),false);
   await evaluate(()=>self.ShorthandStorage.saveSettings=window.__realSuggestionSave);await toggle();await wait(()=>!document.getElementById('suggestionsEnabled').disabled&&document.getElementById('suggestionsMsg').textContent.includes('saved: on'));await shot(theme,'saved-on');assert.equal(await evaluate(()=>self.ShorthandStorage.getAll().then(d=>d.settings.suggestionsEnabled)),true);
  }
 }finally{await app.close();}
}
(async()=>{for(const b of (process.argv.slice(2).length?process.argv.slice(2):['chrome','firefox']))await run(b);console.log(JSON.stringify({captures:records.length,minText:Math.min(...records.flatMap(r=>r.text.map(t=>t.ratio))),minKnob:Math.min(...records.filter(r=>!r.disabled).map(r=>r.knobContrast)),minFocus:Math.min(...records.filter(r=>r.state==='focused').map(r=>r.outline.ratio))}));})().catch(e=>{console.error(e);process.exitCode=1;});
